/*
 * Copyright 2010-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license
 * that can be found in the LICENSE file.
 */

package kotlin.io

// TODO: This interface is a temporary solution for common collections and not used in Native.
internal actual interface Serializable